﻿#include <AEEngine.h>
#include "Rasterizer.h"
#include "AttributeInterpolator.h"

namespace Rasterizer
{
	/*struct OrderedTriangle
	{
		const AEVec2* top;
		const AEVec2* mid;
		const AEVec2* bot;
		bool midIsLeft;
	};
	
	OrderedTriangle OrderTriangle(const AEVec2& v0, const AEVec2& v1, const AEVec2& v2)
	{
		const AEVec2* v[3] = { &v0, &v1, &v2 };
		if (v[0]->y < v[1]->y) std::swap(v[0], v[1]);
		if (v[1]->y < v[2]->y) std::swap(v[1], v[2]);
		if (v[0]->y < v[1]->y) std::swap(v[0], v[1]);
		float cross = (v[2]->x - v[0]->x) * (v[1]->y - v[0]->y) - (v[2]->y - v[0]->y) * (v[1]->x - v[0]->x);
		return { v[0], v[1], v[2], cross < 0 };
	}*/
	

	bool EvaluateCase(AEVec2 v0, AEVec2 v1, AEVec2 v2, int& top, int& mid, int& bottom) {

		//Cases 1,2 and 3
		if (v0.y > v1.y) {

			if (v1.y > v2.y) {
				//Case 1
				top = 0;
				mid = 1;
				bottom = 2;
				return true;
			}
			else if (v0.y > v2.y) {
				//Case 2
				top = 0;
				mid = 2;
				bottom = 1;
				return false;
			}
			else {
				//Case 3
				top = 2;
				mid = 0;
				bottom = 1;
				return true;
			}

		}
		else {
			//Cases 4, 5 and 6
			if (v0.y > v2.y) {
				//Case 4
				top = 1;
				mid = 0;
				bottom = 2;
				return false;
			}
			else if (v1.y > v2.y) {
				//Case 5
				top = 1;
				mid = 2;
				bottom = 0;
				return true;
			}
			else {
				//Case 6
				top = 2;
				mid = 1;
				bottom = 0;
				return false;
			}
		}
	}

	void FillTriangleNaive(const AEVec2& v0, const AEVec2& v1, const AEVec2& v2, const Color& c)
	{
		const AEVec2* vTop = &v0;
		const AEVec2* vMid = &v1;
		const AEVec2* vBot = &v2;

		if (vTop->y < vMid->y) std::swap(vTop, vMid);
		if (vMid->y < vBot->y) std::swap(vMid, vBot);
		if (vTop->y < vMid->y) std::swap(vTop, vMid);

		AEVec2 vTopBot = (*vTop) - (*vBot);
		AEVec2 vTopMid = (*vTop) - (*vMid);
		float crossProduct = vTopBot.x * vTopMid.y - vTopBot.y * vTopMid.x;
		bool midIsLeft = crossProduct < 0;

		float mTopMid = (vMid->x - vTop->x) / (vMid->y - vTop->y);
		float mTopBot = (vBot->x - vTop->x) / (vBot->y - vTop->y);
		float mMidBot = (vBot->x - vMid->x) / (vBot->y - vMid->y);

		float xL = Round(vTop->x);
		float xR = Round(vTop->x);

		int y;
		for (y = Round(vTop->y); y >= Round(vMid->y); y--) {
			for (int x = xL; x <= xR; ++x) {
				FrameBuffer::SetPixel(x, y, c);
			}

			xL -= midIsLeft ? mTopMid : mTopBot;
			xR -= midIsLeft ? mTopBot : mTopMid;
		}

		//yE = Round(vtx[bot]->y);
		if (midIsLeft)
			xL = vMid->x;
		else
			xR = vMid->x;

		for (y; y >=  Round(vBot->y); y--) {
			for (int x = xL; x <= xR; ++x) {
				FrameBuffer::SetPixel(x, y, c);
			}

			xL -= midIsLeft ? mMidBot : mTopBot;
			xR -= midIsLeft ? mTopBot : mMidBot;
		}
	}

	void FillTriangleTopLeft(const AEVec2& v0, const AEVec2& v1, const AEVec2& v2, const Color& c)
	{
		int top, mid, bot;
		const AEVec2* vtx[3] = { &v0,&v1,&v2 };
		bool midIsLeft = EvaluateCase(v0, v1, v2, top, mid, bot);

		float mTopMid = (vtx[mid]->x - vtx[top]->x) / (vtx[mid]->y - vtx[top]->y);
		float mTopBot = (vtx[bot]->x - vtx[top]->x) / (vtx[bot]->y - vtx[top]->y);
		float mMidBot = (vtx[bot]->x - vtx[mid]->x) / (vtx[bot]->y - vtx[mid]->y);

		int yS = Ceiling(vtx[top]->y);
		int yE = Ceiling(vtx[mid]->y) + 1;

		float xL = Round(vtx[top]->x);
		float xR = Round(vtx[top]->x) - 1;

		int y;
		for (y = yS; y >= yE; y--) {
			for (int x = xL; x <= xR; ++x) {
				FrameBuffer::SetPixel(x, y, c);
			}

			xL -= midIsLeft ? mTopMid : mTopBot;
			xR -= midIsLeft ? mTopBot : mTopMid;
		}

		if (midIsLeft)
			xL = vtx[mid]->x;
		else
			xR = vtx[mid]->x - 1;

		yE = Ceiling(vtx[bot]->y) + 1;

		for (y; y >= yE; y--) {
			for (int x = xL; x <= xR; ++x) {
				FrameBuffer::SetPixel(x, y, c);
			}

			xL -= midIsLeft ? mMidBot : mTopBot;
			xR -= midIsLeft ? mTopBot : mMidBot;
		}
	}

	/// -----------------------------------------------------------------------
	///	DRAW TRIANGLE ALGORITHM IMPLEMENTATIONS
	/// 
	/// 
	/// enum	EDrawLineMethod
	///	\brief	Specifies which method should be used when drawing a line. 
	EDrawTriangleMethod currentDrawTriangle = eDT_BILINEAR;

	void DrawTriangle(const Vertex& v0, const Vertex& v1, const Vertex& v2)
	{
		switch (currentDrawTriangle)
		{
			case Rasterizer::eDT_BILINEAR:
				DrawTriangleBiLinear(v0, v1, v2);
				break;
			case Rasterizer::eDT_PLANE_NORMAL:
				DrawTrianglePlaneNormal(v0, v1, v2);
				break;
			case Rasterizer::eDT_BARYCENTRIC:
				DrawTriangleBarycentric(v0, v1, v2);
				break;
			case Rasterizer::eDT_PINEDA:
				DrawTrianglePineda(v0, v1, v2);
				break;
			case Rasterizer::eDT_SHADED:
				const float vertices[] = {
					v0.mPosition.x, v0.mPosition.y, v0.mColor.r, v0.mColor.g, v0.mColor.b, v0.mColor.a,
					v1.mPosition.x, v1.mPosition.y, v1.mColor.r, v1.mColor.g, v1.mColor.b, v1.mColor.a,
					v2.mPosition.x, v2.mPosition.y, v2.mColor.r, v2.mColor.g, v2.mColor.b, v2.mColor.a
				};

				DrawTriangleShaded(vertices, 6, FShaderColor);
				break;
		}
	}

	void DrawTriangleBiLinear(const Vertex& v0, const Vertex& v1, const Vertex& v2)
	{
		const Vertex* vTop = &v0;
		const Vertex* vMid = &v1;
		const Vertex* vBot = &v2;

		if (vTop->mPosition.y < vMid->mPosition.y) std::swap(vTop, vMid);
		if (vMid->mPosition.y < vBot->mPosition.y) std::swap(vMid, vBot);
		if (vTop->mPosition.y < vMid->mPosition.y) std::swap(vTop, vMid);

		AEVec2 vTopBot = vTop->mPosition - vBot->mPosition;
		AEVec2 vTopMid = vTop->mPosition - vMid->mPosition;
		float crossProduct = vTopBot.x * vTopMid.y - vTopBot.y * vTopMid.x;
		bool midIsLeft = crossProduct < 0;

		float mTopMid = (vMid->mPosition.x - vTop->mPosition.x) / (vMid->mPosition.y - vTop->mPosition.y);
		float mTopBot = (vBot->mPosition.x - vTop->mPosition.x) / (vBot->mPosition.y - vTop->mPosition.y);
		float mMidBot = (vBot->mPosition.x - vMid->mPosition.x) / (vBot->mPosition.y - vMid->mPosition.y);

		float xL = Round(vTop->mPosition.x);
		float xR = Round(vTop->mPosition.x) - 1;

		Color cL, cR, c;
		cL = cR = vTop->mColor;
		Color cTopMidStep = (vMid->mColor - vTop->mColor) / abs(vTop->mPosition.y - vMid->mPosition.y);
		Color cTopBotStep = (vBot->mColor - vTop->mColor) / abs(vTop->mPosition.y - vBot->mPosition.y);
		Color cStep;
		int y;
		for (y = Ceiling(vTop->mPosition.y); y >= Ceiling(vMid->mPosition.y) + 1; y--) {
			c = cL;
			cStep = (cR - cL) / abs(xR - xL);
			for (int x = xL; x <= xR; ++x) {
				
				FrameBuffer::SetPixel(x, y, c);
				c += cStep;
			}
			cL += midIsLeft ? cTopMidStep : cTopBotStep;
			cR += midIsLeft ? cTopBotStep : cTopMidStep;
			xL -= midIsLeft ? mTopMid : mTopBot;
			xR -= midIsLeft ? mTopBot : mTopMid;
		}

		if (midIsLeft) {
			xL = vMid->mPosition.x;
			cL = vMid->mColor;
		}
		else
		{
			xR = vMid->mPosition.x - 1;
			cR = vMid->mColor;
		}

		Color cMidBotStep = (vBot->mColor - vMid->mColor) / abs(vBot->mPosition.y - vMid->mPosition.y);

		for (y; y >= Ceiling(vBot->mPosition.y) + 1; y--) {
			
			c = cL;
			cStep = (cR - cL) / abs(xR - xL);
			for (int x = xL; x <= xR; ++x) {
				FrameBuffer::SetPixel(x, y, c);
				c += cStep;
			}

			cL += midIsLeft ? cMidBotStep : cTopBotStep;
			cR += midIsLeft ? cTopBotStep : cMidBotStep;
			xL -= midIsLeft ? mMidBot : mTopBot;
			xR -= midIsLeft ? mTopBot : mMidBot;
		}
	}

	void DrawTrianglePlaneNormal(const Vertex& v0, const Vertex& v1, const Vertex& v2)
	{
		const Vertex* vTop = &v0;
		const Vertex* vMid = &v1;
		const Vertex* vBot = &v2;

		if (vTop->mPosition.y < vMid->mPosition.y) std::swap(vTop, vMid);
		if (vMid->mPosition.y < vBot->mPosition.y) std::swap(vMid, vBot);
		if (vTop->mPosition.y < vMid->mPosition.y) std::swap(vTop, vMid);

		AEVec2 vTopBot = vTop->mPosition - vBot->mPosition;
		AEVec2 vTopMid = vTop->mPosition - vMid->mPosition;
		float crossProduct = vTopBot.x * vTopMid.y - vTopBot.y * vTopMid.x;
		bool midIsLeft = crossProduct < 0;

		float mTopMid = (vMid->mPosition.x - vTop->mPosition.x) / (vMid->mPosition.y - vTop->mPosition.y);
		float mTopBot = (vBot->mPosition.x - vTop->mPosition.x) / (vBot->mPosition.y - vTop->mPosition.y);
		float mMidBot = (vBot->mPosition.x - vMid->mPosition.x) / (vBot->mPosition.y - vMid->mPosition.y);

		float xL = Round(vTop->mPosition.x);
		float xR = Round(vTop->mPosition.x) - 1;

		Color cL, cR, c;
		cL = cR = vTop->mColor;
		Color cTopMidStep = (vMid->mColor - vTop->mColor) / abs(vTop->mPosition.y - vMid->mPosition.y);
		Color cTopBotStep = (vBot->mColor - vTop->mColor) / abs(vTop->mPosition.y - vBot->mPosition.y);
		Color cStep;
		int y;
		for (y = Ceiling(vTop->mPosition.y); y >= Ceiling(vMid->mPosition.y) + 1; y--) {
			c = cL;
			cStep = (cR - cL) / abs(xR - xL);
			for (int x = xL; x <= xR; ++x) {

				FrameBuffer::SetPixel(x, y, c);
				c += cStep;
			}
			cL += midIsLeft ? cTopMidStep : cTopBotStep;
			cR += midIsLeft ? cTopBotStep : cTopMidStep;
			xL -= midIsLeft ? mTopMid : mTopBot;
			xR -= midIsLeft ? mTopBot : mTopMid;
		}

		if (midIsLeft) {
			xL = vMid->mPosition.x;
			cL = vMid->mColor;
		}
		else
		{
			xR = vMid->mPosition.x - 1;
			cR = vMid->mColor;
		}

		Color cMidBotStep = (vBot->mColor - vMid->mColor) / abs(vBot->mPosition.y - vMid->mPosition.y);

		for (y; y >= Ceiling(vBot->mPosition.y) + 1; y--) {

			c = cL;
			cStep = (cR - cL) / abs(xR - xL);
			for (int x = xL; x <= xR; ++x) {
				FrameBuffer::SetPixel(x, y, c);
				c += cStep;
			}

			cL += midIsLeft ? cMidBotStep : cTopBotStep;
			cR += midIsLeft ? cTopBotStep : cMidBotStep;
			xL -= midIsLeft ? mMidBot : mTopBot;
			xR -= midIsLeft ? mTopBot : mMidBot;
		}
	}

	/*void DrawTriangleBarycentric(const Vertex& v0, const Vertex& v1, const Vertex& v2)
	{
		float xMin = min(v0.mPosition.x, min(v1.mPosition.x, v2.mPosition.x ));
		float xMax = max(v0.mPosition.x, max(v1.mPosition.x, v2.mPosition.x ));
		float yMin = min(v0.mPosition.y, min(v1.mPosition.y, v2.mPosition.y ));
		float yMax = max(v0.mPosition.y, max(v1.mPosition.y, v2.mPosition.y ));

		AEVec2 v01 = v1.mPosition - v0.mPosition;
		AEVec2 v02 = v2.mPosition - v0.mPosition;
		float n = v01.CrossMag(v02);

		Color c;
		for (int y = Round(yMin); y <= Round(yMax); y++) {
			for (int x = Round(xMin); x <= Round(xMax); x++) {
				AEVec2 p = AEVec2(x, y);
				AEVec2 p0 = p - v0.mPosition;
				AEVec2 p1 = p - v1.mPosition;
				AEVec2 p2 = p - v2.mPosition;

				float lambda1 = (p2.x * p0.y - p2.y * p0.x) / n;
				float lambda2 = (p0.x * p1.y - p0.y * p1.x) / n;
				float lambda0 = 1 - lambda1 - lambda2;

				if (lambda0 < 0 || lambda1 < 0 || lambda2 < 0)
					continue;
				c = v0.mColor * lambda0 + v1.mColor * lambda1 + v2.mColor * lambda2;
				FrameBuffer::SetPixel(x,y,c) ;
			}
		}
	}*/

	void DrawTriangleBarycentric(const Vertex& v0, const Vertex& v1, const Vertex& v2)
	{
		int xMin = Round(min(v0.mPosition.x,min(v1.mPosition.x, v2.mPosition.x)));
		int xMax = Round(max(v0.mPosition.x,max(v1.mPosition.x, v2.mPosition.x)));
		int yMin = Round(min(v0.mPosition.y,min(v1.mPosition.y, v2.mPosition.y)));
		int yMax = Round(max(v0.mPosition.y,max(v1.mPosition.y, v2.mPosition.y)));

		AEVec2 v01 = v1.mPosition - v0.mPosition;
		AEVec2 v02 = v2.mPosition - v0.mPosition;

		float n = v01.CrossMag(v02);

		if (fabs(n) < 1e-6f)
			return;

		float lambda1XInc = (v2.mPosition.y - v0.mPosition.y) / n;
		float lambda1YInc = (v0.mPosition.x - v2.mPosition.x) / n;

		float lambda2XInc = (v0.mPosition.y - v1.mPosition.y) / n;
		float lambda2YInc = (v1.mPosition.x - v0.mPosition.x) / n;
		AEVec2 p(xMin, yMin);

		AEVec2 p0 = p - v0.mPosition;
		AEVec2 p1 = p - v1.mPosition;
		AEVec2 p2 = p - v2.mPosition;

		float lambda1Row = (p2.x * p0.y - p2.y * p0.x) / n;
		float lambda2Row = (p0.x * p1.y - p0.y * p1.x) / n;

		for (int y = yMin; y <= yMax; ++y)
		{
			float lambda1 = lambda1Row;
			float lambda2 = lambda2Row;

			for (int x = xMin; x <= xMax; ++x)
			{
				float lambda0 = 1.0f - lambda1 - lambda2;
				if (lambda0 >= 0.0f && 	lambda1 >= 0.0f && lambda2 >= 0.0f)
				{
					Color c = v0.mColor * lambda0 +	v1.mColor * lambda1 + v2.mColor * lambda2;
					FrameBuffer::SetPixel(x, y, c);
				}
				lambda1 += lambda1XInc;
				lambda2 += lambda2XInc;
			}
			lambda1Row += lambda1YInc;
			lambda2Row += lambda2YInc;
		}		
	}

	float EdgeFunction(const AEVec2& a, const AEVec2& b, const AEVec2& p) {
		return (b.x - a.x) * (p.y - a.y) - (b.y - a.y) * (p.x - a.x);
	}

	void DrawTrianglePineda(const Vertex& v0, const Vertex& v1, const Vertex& v2)
	{
		float xMin = min(v0.mPosition.x, min(v1.mPosition.x, v2.mPosition.x));
		float xMax = max(v0.mPosition.x, max(v1.mPosition.x, v2.mPosition.x));
		float yMin = min(v0.mPosition.y, min(v1.mPosition.y, v2.mPosition.y));
		float yMax = max(v0.mPosition.y, max(v1.mPosition.y, v2.mPosition.y));

		float area = EdgeFunction(v0.mPosition, v1.mPosition, v2.mPosition);
		AEVec2 edge0 = v0.mPosition - v1.mPosition;
		AEVec2 edge1 = v1.mPosition - v2.mPosition;
		AEVec2 edge2 = v2.mPosition - v0.mPosition;

		for (int y = yMin; y <= yMax; ++y)
		{
			for (int x = xMin; x <= xMax; ++x)
			{
				AEVec2 p(x, y);
				float lambda0 = EdgeFunction(v1.mPosition, v2.mPosition, p);
				float lambda1 = EdgeFunction(v2.mPosition, v0.mPosition, p);
				float lambda2 = EdgeFunction(v0.mPosition, v1.mPosition, p);

				lambda0 /= area;
				lambda1 /= area;
				lambda2 /= area;

				bool overlaps = true;
				overlaps &= (lambda0 == 0 ? ((edge0.y == 0 && edge0.x > 0) || edge0.y < 0) : (lambda0 > 0));
				overlaps &= (lambda1 == 0 ? ((edge1.y == 0 && edge1.x > 0) || edge1.y < 0) : (lambda1 > 0));
				overlaps &= (lambda2 == 0 ? ((edge2.y == 0 && edge2.x > 0) || edge2.y < 0) : (lambda2 > 0));

				if (overlaps) {
					Color c = v0.mColor * lambda0 + v1.mColor * lambda1 + v2.mColor * lambda2;
					FrameBuffer::SetPixel(x, y, c);
				}
			}
		}
	}

	void DrawTriangleShaded(const float* vertices, const unsigned int& vertexSize, ShaderFunc shader)
	{		
		// vertices [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15]
		// vertices [x,y,r,g,b,a,x,y,r,g,b, a, x, y, r, g,b,a]
		AEVec2 v0(vertices[0], vertices[1]);
		AEVec2 v1(vertices[vertexSize], vertices[vertexSize + 1]);
		AEVec2 v2(vertices[vertexSize*2], vertices[vertexSize*2 + 1]);

		float xMin = min(v0.x, min(v1.x, v2.x));
		float xMax = max(v0.x, max(v1.x, v2.x));
		float yMin = min(v0.y, min(v1.y, v2.y));
		float yMax = max(v0.y, max(v1.y, v2.y));
		
		AttributeInterpolator interpolator;
		interpolator.Init(vertices, vertexSize);

		for (float y = yMin; y <= yMax; ++y)
		{			
			for (float x = xMin; x <= xMax; ++x)
			{
				bool overlaps = interpolator.Evaluate(x, y);
				if (overlaps) {
					float* fragData = interpolator.GetCurrentValues();

					FragmentInput shaderData;
					shaderData.x = x;
					shaderData.y = y;

					// Original index footprint works again (Indices 2, 3, 4, 5)
					shaderData.color = Color(fragData[2], fragData[3], fragData[4], fragData[5]);

					Color c = shader(shaderData);
					FrameBuffer::SetPixel(Round(x), Round(y), c);
				}
			}
		}
	}

	EDrawTriangleMethod GetDrawTriangleMethod() {
		return currentDrawTriangle;
	}

	void SetDrawTriangleMethod(EDrawTriangleMethod triangleMethod) {
		currentDrawTriangle = triangleMethod;
	}

}