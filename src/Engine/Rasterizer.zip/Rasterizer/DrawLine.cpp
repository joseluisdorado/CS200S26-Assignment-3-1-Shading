#include <AEEngine.h>
#include "Rasterizer.h"


namespace Rasterizer
{
	/// -----------------------------------------------------------------------
	///	LINE ALGORITHM IMPLEMENTATIONS
	/// 
	/// 
	/// enum	EDrawLineMethod
	///	\brief	Specifies which method should be used when drawing a line. 
	EDrawLineMethod currentDrawLine = eDL_NAIVE;

	void DrawHorizontalLine(const AEVec2& p1, const AEVec2& p2, const Color& c) {
		float dx = p2.x - p1.x;
		int step = dx >= 0 ? 1 : -1;

		unsigned int sx = Round(p1.x), ex = Round(p2.x) + step, y = Round(p1.y);

		for (int x = sx; x != ex; x += step) {
			//SetPixel(x, y, c); This is no the method from Framebuffer!
			FrameBuffer::SetPixel(x, y, c);
		}
	}

	void DrawVerticalLine(const AEVec2& p1, const AEVec2& p2, const Color& c) {
		float dy = p2.y - p1.y;
		int step = dy >= 0 ? 1 : -1;

		unsigned int sy = Round(p1.y), ey = Round(p2.y) + step, x = Round(p1.x);

		for (unsigned int y = sy; y != ey; y += step) {
			FrameBuffer::SetPixel(x, y, c);
		}
	}

	void DrawDiagonalLine(const AEVec2& p1, const AEVec2& p2, const Color& c) {
		float dy = p2.y - p1.y;
		int ystep = dy >= 0 ? 1 : -1;

		float dx = p2.x - p1.x;
		int xstep = dx >= 0 ? 1 : -1;

		unsigned int sx = Round(p1.x), ex = Round(p2.x) + xstep, y = Round(p1.y);
		unsigned int sy = Round(p1.y), ey = Round(p2.y) + ystep, x = Round(p1.x);

		//for (unsigned int y = sy, x = sx; y != ey || x != ex; x += xstep, y += ystep) //infinite loop due to OR !

		for (unsigned int y = sy, x = sx; y != ey && x != ex; x += xstep, y += ystep) {
			FrameBuffer::SetPixel(x, y, c);
		}
	}

	void DrawRect(const AEVec2& r, const AEVec2& size, const Color& c) {
		AEVec2 topL = AEVec2(r.x - size.x, r.y - size.y);
		AEVec2 topR = AEVec2(r.x + size.x, r.y - size.y);
		AEVec2 bottomL = AEVec2(r.x - size.x, r.y + size.y);
		AEVec2 bottomR = AEVec2(r.x + size.x, r.y + size.y);

		DrawHorizontalLine(topL, topR, c);
		DrawHorizontalLine(bottomL, bottomR, c);
		DrawVerticalLine(bottomL, topL, c);
		DrawVerticalLine(bottomR, topR, c);
	}


	void DrawLine(const AEVec2& p1, const AEVec2& p2, const Color& c) {

		int dx = Round(p2.x - p1.x);
		int dy = Round(p2.y - p1.y);

		if (dx == 0) {
			DrawVerticalLine(p1, p2, c);
		}
		else if (dy == 0) {
			DrawHorizontalLine(p1, p2, c);
		}
		else if (abs(dx) == abs(dy)) {
			DrawDiagonalLine(p1, p2, c);
		}
		else {
			switch(currentDrawLine) {
				case EDrawLineMethod::eDL_NAIVE:
					DrawLineNaive(p1, p2, c);
					break;
				case EDrawLineMethod::eDL_DDA:
					DrawLineDDA(p1, p2, c);
					break;
				case EDrawLineMethod::eDL_BRESENHAM:
					DrawLineBresenham(p1, p2, c);
					break;

			}
		}
	}

	// Naive
	void DrawLineNaive(const AEVec2& p1, const AEVec2& p2, const Color& c) {
		float dx = p2.x - p1.x;
		float dy = p2.y - p1.y;

		float max = max(abs(dy), abs(dx));

		float x = p1.x;
		float y = p1.y;
		
		for (int i=0; i <= max; i++) {
			x += dx / max;
			y += dy / max;
			FrameBuffer::SetPixel(x, y, c);
		}
	}

	void DrawLineDDA(const AEVec2& p1, const AEVec2& p2, const Color& c)
	{
		// Calculate dx and dy
		float dx = p2.x - p1.x;
		float dy = p2.y - p1.y;

		float m = abs(dy / dx);

		if (m < 1.0f) {
			int xstep = dx > 0 ? 1 : -1;
			float ystep = dy > 0 ? m : -m;

			int sX = Round(p1.x);
			int eX = Round(p2.x) + xstep;
			float y = p1.y;
			for (int x = sX; x != eX; x += xstep, y += ystep) {
				FrameBuffer::SetPixel(x, Round(y), c);
			}
		}
		else {
			int ystep = dy > 0 ? 1 : -1;
			float xstep = dx > 0 ? 1.0f / m : -1.0f / m;
			int sY = Round(p1.y);
			int eY = Round(p2.y) + ystep;
			float x = p1.x;
			for (int y = sY; y != eY; y += ystep, x += xstep) {
				FrameBuffer::SetPixel(Round(x), y, c);
			}
		}
	}

	void DrawLineBresenham(const AEVec2& p1, const AEVec2& p2, const Color& c)
	{
		// Calculate dx and dy
		int dx = p2.x - p1.x;
		int dy = p2.y - p1.y;
		int stepX = dx > 0 ? 1 : -1;
		int stepY = dy > 0 ? 1 : -1;
		
		//float m = abs(dy / dx);
		dx = Round(abs(dx));
		dy = Round(abs(dy));

		if (dx > dy) {
			int dp = 2 * abs(dy) - abs(dx);
			int sX = Round(p1.x);
			int eX = Round(p2.x) + stepX;
			float y = Round(p1.y);
			
			for (int x = sX; x != eX;) {
				FrameBuffer::SetPixel(x, y, c);
				if (dp > 0)
				{
					x += stepX;
					y += stepY;
					dp += 2 * dy - 2 * dx;
				}
				else {
					x += stepX;
					dp += 2 * dy;
				}
			}
		}
		else {
			int dp = 2 * abs(dx) - abs(dy);
			int sY = Round(p1.y);
			int eY = Round(p2.y) + stepY;
			float x = Round(p1.x);
			
			for (int y = sY; y != eY;) {
				FrameBuffer::SetPixel(x, y, c);
				if (dp > 0)
				{
					x += stepX;
					y += stepY;
					dp += 2 * dx - 2 * dy;
				}
				else {
					y += stepY;
					dp += 2 * dx;
				}
			}
		}
	}

	void DrawLine(const AEVec2& p1, const Color& c1, const AEVec2& p2, const Color& c2) 
	{
		float dx = p2.x - p1.x;
		float dy = p2.y - p1.y;

		float m = abs(dy / dx);

		if (m < 1.0f) {
			int xstep = dx > 0 ? 1 : -1;
			float ystep = dy > 0 ? m : -m;
			//float stepR = (c1.r - c2.r) / dx;
			//float stepB = (c1.b - c2.b) / dx;
			//float stepG = (c1.g - c2.g) / dx;
			//float stepA = (c1.a - c2.a) / dx;

			int sX = Round(p1.x);
			int eX = Round(p2.x) + xstep;
			float y = p1.y;
			Color c = c1;
			Color cstep = (c2 - c1) /abs(dx);

			for (int x = sX; x != eX; x += xstep, y += ystep) {
				//c.r += stepR;
				//c.g += stepG;
				//c.b += stepB;
				//c.a += stepA;
				c += cstep;
				FrameBuffer::SetPixel(x, Round(y), c);
			}
		}
		else {
			int ystep = dy > 0 ? 1 : -1;
			float xstep = dx > 0 ? 1.0f / m : -1.0f / m;
			
			//float stepR = (c1.r - c2.r) / dy;
			//float stepB = (c1.b - c2.b) / dy;
			//float stepG = (c1.g - c2.g) / dy;
			//float stepA = (c1.a - c2.a) / dy;

			
			int sY = Round(p1.y);
			int eY = Round(p2.y) + ystep;
			float x = p1.x;
			Color c = c1;
			Color cstep = (c2 - c1) / abs(dy);

			for (int y = sY; y != eY; y += ystep, x += xstep) {
				//c.r += stepR;
				//c.g += stepG;
				//c.b += stepB;
				//c.a += stepA;
				c += cstep;
				FrameBuffer::SetPixel(Round(x), y, c);
			}
		}
	}
	
	/// @TODO
	// ------------------------------------------------------------------------
	/// \fn	GetDrawLineMethod
	/// \brief	Return the current draw line method.
	EDrawLineMethod GetDrawLineMethod() {
		return currentDrawLine;
	}

	/// @TODO
	// ------------------------------------------------------------------------
	/// \fn	GetDrawLineMethod
	/// \brief	Set the current draw line method to that given as input.
	void SetDrawLineMethod(EDrawLineMethod lineMethod) {
		currentDrawLine = lineMethod;
	}
}