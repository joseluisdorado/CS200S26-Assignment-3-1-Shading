#include <AEEngine.h>
#include "Rasterizer.h"


namespace Rasterizer
{
	/// -----------------------------------------------------------------------
	///	Circle ALGORITHM IMPLEMENTATIONS
	/// 
	/// 
	/// enum	EDrawCircleMethod
	///	\brief	Specifies which method should be used when drawing a circle. 
	EDrawCircleMethod currentDrawCircle = eDC_NAIVE;

	static void SetPixelEightWay(unsigned int cX, unsigned int cY, unsigned int x, unsigned int y, const Color& c)
	{
		FrameBuffer::SetPixel(cX + x, cY + y, c);
		FrameBuffer::SetPixel(cX + x, cY - y, c);
		FrameBuffer::SetPixel(cX - x, cY + y, c);
		FrameBuffer::SetPixel(cX - x, cY - y, c);
		FrameBuffer::SetPixel(cX + y, cY + x, c);
		FrameBuffer::SetPixel(cX + y, cY - x, c);
		FrameBuffer::SetPixel(cX - y, cY + x, c);
		FrameBuffer::SetPixel(cX - y, cY - x, c);
	}

	void DrawCircle(const AEVec2& center, float radius, const Color& c)
	{
		if (Round(radius) == 0)
		{
			FrameBuffer::SetPixel(Round(center.x), Round(center.y), c);
			return;
		}

		switch (currentDrawCircle)
		{
			case Rasterizer::eDC_NAIVE:
				DrawCircleNaive(center, radius, c);
			break;
			case Rasterizer::eDC_PARAMETRIC:
				DrawCircleParametric(center, radius, c);
			break;
			case Rasterizer::eDC_MIDPOINT:
				DrawCircleMidpoint(center, radius, c);
			break;
			case Rasterizer::eDC_BRESENHAM:
				DrawCircleBresenham(center, radius, c);
				break;

		}
	}

	void DrawCircleNaive(const AEVec2& center, float radius, const Color& c)
	{
		unsigned int cX = Round(center.x);
		unsigned int cY = Round(center.y);
		unsigned int eX = Round(sqrtf(2.0f) * radius / 2.0f);

		for (unsigned int x = 0; x <= eX; ++x)
		{
			unsigned int y = Round(sqrtf(radius * radius - (x * x)));
			SetPixelEightWay(cX, cY, x, y, c);
		}
	}

	void DrawCircleParametric(const AEVec2& center, float radius, const Color& c)
	{
		const float parametricPrecision = 50.0f;
		const float angleStep = TWO_PI / parametricPrecision;

		for (float angle = 0.0f; angle < TWO_PI; angle += angleStep)
		{
			AEVec2 p1 = center + AEVec2(cosf(angle), sinf(angle)) * radius;
			AEVec2 p2 = center + AEVec2(cosf(angle + angleStep), sinf(angle + angleStep)) * radius;
			DrawLine(p1, p2, c);
		}
	}


	void DrawCircleMidpoint(const AEVec2& center, float radius, const Color& c)
	{
		int cX = Round(center.x);
		int cY = Round(center.y);

		int x = 0;
		int y = Round(radius);

		int p = 1 - y;

		while (x <= y)
		{
			SetPixelEightWay(cX, cY, x, y, c);

			++x;

			if (p < 0)
			{
				p += 2 * x + 1;
			}
			else
			{
				--y;
				p += 2 * x - 2 * y + 1;
			}
		}
	}

	void DrawCircleBresenham(const AEVec2& center, float radius, const Color& c)
	{
		int cX = Round(center.x);
		int cY = Round(center.y);

		int r = Round(radius);

		int x = 0;
		int y = r;

		// Decision variable
		int d = 3 - (2 * r);

		while (x <= y)
		{
			SetPixelEightWay(cX, cY, x, y, c);

			if (d < 0)
			{
				d = d + (4 * x) + 6;
			}
			else
			{
				d = d + (4 * (x - y)) + 10;
				--y;
			}

			++x;
		}
	}

	void DrawFilledCircle2(const AEVec2& center,float radius,const Color& colorInner,const Color& colorOuter)
	{
		int cX = Round(center.x);
		int cY = Round(center.y);

		int r = Round(radius);
		float rSq = radius * radius;

		for (int y = -r; y <= r; ++y)
		{
			for (int x = -r; x <= r; ++x)
			{
				float distSq = static_cast<float>(x * x + y * y);

				if (distSq <= rSq)
				{
					float dist = sqrtf(distSq);
					float t = dist / radius;

					Color c;
					c.r = colorInner.r + t * (colorOuter.r - colorInner.r);
					c.g = colorInner.g + t * (colorOuter.g - colorInner.g);
					c.b = colorInner.b + t * (colorOuter.b - colorInner.b);
					c.a = colorInner.a + t * (colorOuter.a - colorInner.a);

					FrameBuffer::SetPixel(cX + x, cY + y, c);
				}
			}
		}
	}

	void DrawFilledCircle(
		const AEVec2& center,
		float radius,
		const Color& colorTL,
		const Color& colorTR,
		const Color& colorBL,
		const Color& colorBR)
	{
		int cX = Round(center.x);
		int cY = Round(center.y);

		int r = Round(radius);
		float rSq = radius * radius;

		for (int y = -r; y <= r; ++y)
		{
			for (int x = -r; x <= r; ++x)
			{
				float distSq = float(x * x + y * y);

				if (distSq <= rSq)
				{
					// Normalize to [0,1] in bounding box
					float u = (x + radius) / (2.0f * radius);
					float v = (y + radius) / (2.0f * radius);

					// Bilinear interpolation
					Color top, bottom, c;

					top.r = colorTL.r + u * (colorTR.r - colorTL.r);
					top.g = colorTL.g + u * (colorTR.g - colorTL.g);
					top.b = colorTL.b + u * (colorTR.b - colorTL.b);
					top.a = colorTL.a + u * (colorTR.a - colorTL.a);

					bottom.r = colorBL.r + u * (colorBR.r - colorBL.r);
					bottom.g = colorBL.g + u * (colorBR.g - colorBL.g);
					bottom.b = colorBL.b + u * (colorBR.b - colorBL.b);
					bottom.a = colorBL.a + u * (colorBR.a - colorBL.a);

					c.r = top.r + v * (bottom.r - top.r);
					c.g = top.g + v * (bottom.g - top.g);
					c.b = top.b + v * (bottom.b - top.b);
					c.a = top.a + v * (bottom.a - top.a);

					FrameBuffer::SetPixel(cX + x, cY + y, c);
				}
			}
		}
	}

	void DrawFilledCircle2(
		const AEVec2& center,
		float radius,
		const Color& c00, // top-left
		const Color& c10, // top-right
		const Color& c01, // bottom-left
		const Color& c11) // bottom-right
	{
		int cX = Round(center.x);
		int cY = Round(center.y);

		int r = Round(radius);
		float rSq = radius * radius;

		for (int y = -r; y <= r; ++y)
		{
			for (int x = -r; x <= r; ++x)
			{
				float distSq = float(x * x + y * y);

				if (distSq <= rSq)
				{
					// Normalize to [-1,1]
					float nx = x / radius;
					float ny = y / radius;

					// Warp square -> circle (key trick)
					float len = sqrtf(nx * nx + ny * ny);
					float u = 0.5f + 0.5f * (nx / (len + 1e-5f));
					float v = 0.5f + 0.5f * (ny / (len + 1e-5f));

					// Bilinear interpolation
					Color top, bottom, c;

					top.r = c00.r + u * (c10.r - c00.r);
					top.g = c00.g + u * (c10.g - c00.g);
					top.b = c00.b + u * (c10.b - c00.b);
					top.a = c00.a + u * (c10.a - c00.a);

					bottom.r = c01.r + u * (c11.r - c01.r);
					bottom.g = c01.g + u * (c11.g - c01.g);
					bottom.b = c01.b + u * (c11.b - c01.b);
					bottom.a = c01.a + u * (c11.a - c01.a);

					c.r = top.r + v * (bottom.r - top.r);
					c.g = top.g + v * (bottom.g - top.g);
					c.b = top.b + v * (bottom.b - top.b);
					c.a = top.a + v * (bottom.a - top.a);

					// Optional: soften edge (gives �shader-like� look)
					float edge = 1.0f - (sqrtf(distSq) / radius);
					c.r *= edge;
					c.g *= edge;
					c.b *= edge;

					FrameBuffer::SetPixel(cX + x, cY + y, c);
				}
			}
		}
	}

	EDrawCircleMethod GetDrawCircleMethod()
	{
		return currentDrawCircle;
	}

	void SetDrawCircleMethod(EDrawCircleMethod dlm) {
		currentDrawCircle = dlm;	
	}
}