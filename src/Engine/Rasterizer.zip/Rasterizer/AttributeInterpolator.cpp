#include "AttributeInterpolator.h"
#include "Rounding.h"

namespace Rasterizer
{
    void AttributeInterpolator::Init(const float* vertices, const int attrCount)
    {
		mAttrCount = attrCount;
        mVertices = vertices;

        x0 = vertices[0];  y0 = vertices[1];
        x1 = vertices[attrCount];  y1 = vertices[attrCount+1];
        x2 = vertices[attrCount*2]; y2 = vertices[attrCount*2+1];

        // 2. Pre-calculate the cross-product area
        mArea = (x1 - x0) * (y2 - y0) - (x2 - x0) * (y1 - y0);
        // Prepare our output storage size matching the stride layout
        mCurrentValues.resize(attrCount);
    }

    bool AttributeInterpolator::Evaluate(float x, float y)
    {
        // If the triangle has no area, skip calculation to avoid division by zero
        if (std::abs(mArea) < 1e-6f) return false;

        // 1. Calculate Edge Functions inline at the current pixel coordinate (x, y)
        float w0 = (x2 - x1) * (y - y1) - (y2 - y1) * (x - x1); // EdgeFunction(v1, v2, p)
        float w1 = (x0 - x2) * (y - y2) - (y0 - y2) * (x - x2); // EdgeFunction(v2, v0, p)
        float w2 = (x1 - x0) * (y - y0) - (y1 - y0) * (x - x0); // EdgeFunction(v0, v1, p)

        // 2. Convert to normalized barycentric coordinates
        float lambda0 = w0 / mArea;
        float lambda1 = w1 / mArea;
        float lambda2 = w2 / mArea;

		if (lambda0 < 0 || lambda1 < 0 || lambda2 < 0) 
            return false; // Outside triangle

        for (int i = 0; i < mCurrentValues.size(); i++)
        {
            mCurrentValues[i] =
                lambda0 * mVertices[i] +
                lambda1 * mVertices[mAttrCount + i] +
                lambda2 * mVertices[mAttrCount*2 + i];
        }
    }

    float* AttributeInterpolator::GetCurrentValues()
    {
        return mCurrentValues.data();
    }
}